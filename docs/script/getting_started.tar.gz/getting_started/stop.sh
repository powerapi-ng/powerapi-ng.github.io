#!/bin/bash
set -ueo pipefail
set +x 

docker compose down
